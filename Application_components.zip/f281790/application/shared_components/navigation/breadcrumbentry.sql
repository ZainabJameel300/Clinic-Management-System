prompt --application/shared_components/navigation/breadcrumbentry
begin
--   Manifest
--     BREADCRUMB ENTRY: 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>38485081824928251930
,p_default_application_id=>281790
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ITCS496ZAINAB'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(44648462517870370427)
,p_menu_id=>wwv_flow_imp.id(38966578786102783684)
,p_option_sequence=>10
,p_short_name=>'Most Prescribed Medications Report'
,p_link=>'f?p=&APP_ID.:18:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_imp.component_end;
end;
/
